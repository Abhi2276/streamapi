package stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Emp<K, V> {
	public static <K, V> Stream<V> convertMapToStream(Map<K, V> map) {

		// Return the obtained Stream
		return map

				// Convert the Map to Set<Value>
				.values()

				// Convert the Set to Stream
				.stream();
	}

	public static void main(String[] args) {

		Map<Integer, HashMapEmp> map = new HashMap<>();
		// map.put(new HashMapEmp(1," juhi"," java"));
		HashMapEmp e1 = new HashMapEmp(1, "Tbhi", " java");
		HashMapEmp e2 = new HashMapEmp(2, "Ram", " python");
		HashMapEmp e3 = new HashMapEmp(3, "Aai", " sql");
		HashMapEmp e4 = new HashMapEmp(4, "john", " sql");
		HashMapEmp e5 = new HashMapEmp(5, "deba", " java");

		map.put(1, e1);
		map.put(2, e2);
		map.put(3, e3);
		map.put(4, e4);
		map.put(5, e5);
		// System.out.println(map);
		//

		Stream<HashMapEmp> stream = convertMapToStream(map);

             Map<String, List<String>> studentsByBook = stream
              .collect(Collectors.groupingBy( HashMapEmp::getBook,
                Collectors.mapping(HashMapEmp::getName, Collectors.toList())));

              System.out.println(studentsByBook);


		Map<String, Long> countByBook = stream
				.collect(Collectors.groupingBy(HashMapEmp::getBook, Collectors.counting()));
		System.out.println(countByBook);

		// List<HashMapEmp> output=
		// stream.sorted(Comparator.comparing(HashMapEmp::getName)).collect(Collectors.toList());
		// System.out.println(output);

		// Map<Integer,HashMapEmp>
		// map1=stream.collect(Collectors.groupingBy(e->e.getId(),
		// Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparing(e->e.getName())),Optional::get)));
		// System.out.println(map1);

		// Map<Integer,HashMapEmp>
		// map2=stream.collect(Collectors.groupingBy(e->e.getId(),sorted(Comparator.comparing(HashMapEmp::getName)));
		// System.out.println(map2);

		// System.out.println(list);
		// System.out.println(map);

		// map.stream().sorted().collect(Collector.toList())
		// Map<Integer,Long>
		// map1=list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
//Map<Double,Sample> map1=emp.stream().collect(Collectors.groupingBy(e->e.getSalary(),
//		Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparingInt(e->e.getAge())),Optional::get)));
//System.out.println(map);

	}

	private static Object sorted() {
		// TODO Auto-generated method stub
		return null;
	}

}
