package stream;

public class HashMap_forEach_Method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
