package stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamEx {
	public static void main(String[] args) {
		
	
	
	
	ArrayList<Integer> value=new ArrayList<>();
	value.add(1);
	value.add(55);
	value.add(3);
	value.add(5);
	//value.add(null);
	value.add(2);
	System.out.println(value);
	//filter takes predicate , boolean and return true or false
	List<Integer> res=value.stream().filter(e->e>3).collect(Collectors.toList());
	List<Integer> res1=value.stream().sorted().collect(Collectors.toList());
	
	// sorting
	value.stream().sorted().forEach(System.out::print);
	
	// min
	 Integer integer=value.stream().min((x,y)->x.compareTo(y)).get();
	 System.out.println("min"+ integer);
	 
	// max
	 Integer integer1=value.stream().max((x,y)->x.compareTo(y)).get();
	 System.out.println(" max" + integer1);
	// map-  each element operation  , return value - map(function)
	
	//List<Integer> res2=value.stream().ma
	System.out.println(res);
	System.out.println(res1);
	
	List<String> names=new ArrayList<>();
	names.add("Abhi");
	names.add("Abhinav");
	names.add("shyam");
	names.add("durga");
	
	List<String> out=names.stream().filter(e->e.startsWith("A")).collect(Collectors.toList());
	
	System.out.println(out);
	
	//List<Integer> num=List.of(1,2,3,4,5);
	//List<Integer> out2=num.stream().map(e->e*e).collect(Collectors.toList());
	
	

}
}
